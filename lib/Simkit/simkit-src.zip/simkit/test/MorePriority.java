package simkit.test;

import simkit.Priority;

/**
 * @version $Id: MorePriority.java 1083 2008-06-11 20:41:21Z kastork $
 * @author ahbuss
 */
public class MorePriority extends Priority {
    
    public static final Priority HUMONGOUS = new Priority("Humongous", 100.0);
    public static final Priority MINISCULE = new Priority("Miniscule", -100.0);
    
    public MorePriority(String name, double value) {
        super(name, value);
    }    
}