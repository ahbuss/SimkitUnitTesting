package simkit.random;

import static simkit.stat.NormalQuantile.getQuantile;

/**
 * Generates Normal random variates using the Inverse Transform method
 * 
 * @see simkit.stat.NormalQuantile
 * @author Arnold Buss
 * @version $Id: Normal04Variate.java 1386 2016-10-18 19:08:10Z ahbuss $
 */
public class Normal04Variate extends Normal02Variate {

    @Override
    public double generate() {
        double u = rng.draw();
        return getQuantile(u);
    }

}
