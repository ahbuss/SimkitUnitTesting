/*
 * ContinuousDistribution.java
 *
 * Created on September 19, 2001, 4:32 PM
 */

package simkit.random;

/**
 * An interface for Classes that describe a continuous random variable distribution.
 * 
 * @author  Arnold Buss
 * @version $Id: ContinuousDistribution.java 1370 2015-11-16 19:08:25Z ahbuss $
 */
public interface ContinuousDistribution extends Distribution{
    
    /**
     * 
     * @param x given value
     * @return the value of the probability density function at the given value.
     */
    public double pdf(double x);
    
}

