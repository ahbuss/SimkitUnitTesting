package simkit.random;

/**
 * @version $Id: RandomObjectVariate.java 1083 2008-06-11 20:41:21Z kastork $
 * @author ahbuss
 */
public interface RandomObjectVariate<T> extends RandomVariate {
    public T generateObject();
}