package simkit.smd;

/**
 * A Mover that can be acted on by a Munition and is subject to being killed or
 * damaged.
 *
 * @author Arnold Buss
 * @version $Id: Target.java 1400 2017-02-21 14:23:28Z ahbuss $
 */
public interface Target extends Mover {

    /**
     * Kills this Target.
     */
    public void doKill();

    /**
     * Causes this Target to be damaged.
     *
     * @param damage Defines how this Target is damaged.
     */
    public void doHit(Damage damage);

    /**
     * @return true if this Target has not been killed.
     */
    public boolean isAlive();
}
