package simkit.smdx;

/**
 * Something that has a Side associated with it.
 *
 * @see Side
 * @version $Id: Sided.java 1400 2017-02-21 14:23:28Z ahbuss $
 * @author Arnold Buss
 */
public interface Sided {

    /**
     *
     * @return the Side associated with this Sided.
     */
    public Side getSide();

}
